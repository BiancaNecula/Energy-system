package input;

import entities.Consumer;
import entities.Distributor;
import updates.UpdateCostsChanges;

import java.util.List;

public final class InputGame {
    private long numberOfTurns;
    private List<Consumer> consumers;
    private List<Distributor> distributors;
    private List<List<Consumer>> newConsumers;
    private List<List<UpdateCostsChanges>> costsChanges;

    private static InputGame instance = null;

    private InputGame() {

    }

    /**
     * @return the only instance for this class
     */
    public static InputGame getInstanceOfInput() {
        if (instance == null) {
            instance = new InputGame();
        }
        return instance;
    }

    /**
     * @param numberOfTurns months
     * @param consumers list of consumers
     * @param distributors list of distributors
     * @param newConsumers list of monthly new consumers
     * @param costsChanges list of monthly cost changes
     */
    public void init(final long numberOfTurns, final  List<Consumer> consumers,
                     final List<Distributor> distributors,
                     final List<List<Consumer>> newConsumers,
                     final List<List<UpdateCostsChanges>> costsChanges) {
        this.numberOfTurns = numberOfTurns;
        this.consumers = consumers;
        this.distributors = distributors;
        this.newConsumers = newConsumers;
        this.costsChanges = costsChanges;
    }

    /**
     * @return months
     */
    public long getNumberOfTurns() {
        return numberOfTurns;
    }

    /**
     * @return the list of consumers
     */
    public List<Consumer> getConsumers() {
        return consumers;
    }

    /**
     * @return the list of distributors
     */
    public List<Distributor> getDistributors() {
        return distributors;
    }

    /**
     * @return the list of new consumers
     */
    public List<List<Consumer>> getNewConsumers() {
        return newConsumers;
    }

    /**
     * @return the list of costs updates
     */
    public List<List<UpdateCostsChanges>> getCostsChanges() {
        return costsChanges;
    }
}
