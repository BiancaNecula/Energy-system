package input;

import entities.Consumer;
import entities.Distributor;
import entities.Entity;
import entities.EntityFactory;
import updates.Update;
import updates.UpdateCostsChanges;
import updates.UpdateFactory;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public final class InputLoader {
    /**
     * The path to the input file
     */
    private final String inputPath;

    public InputLoader(final String inputPath) {
        this.inputPath = inputPath;
    }

    /**
     * The method reads the database
     * @return an InputGame object
     */
    public void readData() {
        JSONParser jsonParser = new JSONParser();
        long numberOfTurns = 0;
        List<Consumer> consumers = new ArrayList<>();
        List<Distributor> distributors = new ArrayList<>();
        List<List<Consumer>> newConsumers = new ArrayList<>();
        List<List<UpdateCostsChanges>> costsChanges = new ArrayList<>();

        try {
            JSONObject jsonObject = (JSONObject) jsonParser
                    .parse(new FileReader(inputPath));
            numberOfTurns = (long) jsonObject.get("numberOfTurns");
            JSONObject initialData = (JSONObject) jsonObject.get("initialData");
            JSONArray monthlyUpdates = (JSONArray) jsonObject.get("monthlyUpdates");

            JSONArray consumerData = (JSONArray) initialData.get("consumers");
            JSONArray distributorsData = (JSONArray) initialData.get("distributors");


            if (consumerData != null) {
                for (Object c : consumerData) {
                    Entity entity = EntityFactory.createEntity("consumer",
                            (long) ((JSONObject) c).get("id"),
                            (long) ((JSONObject) c).get("initialBudget"),
                            (long) ((JSONObject) c).get("monthlyIncome"));
                    consumers.add((Consumer) entity);
                }
            } else {
                consumers = null;
            }
            if (distributorsData != null) {
                for (Object d : distributorsData) {
                    Entity entity = EntityFactory.createEntity("distributor",
                            (long) ((JSONObject) d).get("id"),
                            (long) ((JSONObject) d).get("contractLength"),
                            (long) ((JSONObject) d).get("initialBudget"),
                            (long) ((JSONObject) d).get("initialInfrastructureCost"),
                            (long) ((JSONObject) d).get("initialProductionCost"));
                    distributors.add((Distributor) entity);
                }
            } else {
                distributors = null;
            }
            if (monthlyUpdates != null) {
                for (Object obj : monthlyUpdates) {
                    if (((JSONObject) obj).get("newConsumers") != null) {
                        JSONArray newConsumersJSON =
                                (JSONArray) ((JSONObject) obj).get("newConsumers");
                        List<Consumer> tempConsumers = new ArrayList<>();
                        if (newConsumersJSON != null) {
                            for (Object c : newConsumersJSON) {
                                Entity entity = EntityFactory.createEntity("consumer",
                                        (long) ((JSONObject) c).get("id"),
                                        (long) ((JSONObject) c).get("initialBudget"),
                                        (long) ((JSONObject) c).get("monthlyIncome"));
                                tempConsumers.add((Consumer) entity);
                            }
                        } else {
                            tempConsumers = null;
                        }
                        newConsumers.add(tempConsumers);
                    }
                    if (((JSONObject) obj).get("costsChanges") != null) {
                        JSONArray costsChangesJSON =
                                (JSONArray) ((JSONObject) obj).get("costsChanges");
                        List<UpdateCostsChanges> tempCostChanges = new ArrayList<>();
                        if (costsChangesJSON != null) {
                            for (Object o : costsChangesJSON) {
                                Update update = UpdateFactory.createUpdate("costsChanges",
                                        (long) ((JSONObject) o).get("id"),
                                        (long) ((JSONObject) o).get("infrastructureCost"),
                                        (long) ((JSONObject) o).get("productionCost"));
                                tempCostChanges.add((UpdateCostsChanges) update);
                            }
                        } else {
                            tempCostChanges = null;
                        }
                        costsChanges.add(tempCostChanges);
                    }
                }
            } else {
                monthlyUpdates = null;
            }

        } catch (ParseException | IOException e) {
            e.printStackTrace();
        }
        InputGame inputGame = InputGame.getInstanceOfInput();
        inputGame.init(numberOfTurns, consumers, distributors, newConsumers, costsChanges);
    }
}

