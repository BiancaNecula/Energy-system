package updates;

public abstract class Update {
    public Update() {
    }
}
