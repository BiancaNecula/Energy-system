package updates;

public class UpdateCostsChanges extends Update {
    private long id;
    private long infrastructureCost;
    private long productionCost;

    public UpdateCostsChanges(final long id, final long infrastructureCost, final long productionCost) {
        this.id = id;
        this.infrastructureCost = infrastructureCost;
        this.productionCost = productionCost;
    }

    /**
     * @return distributor's id
     */
    public long getId() {
        return id;
    }

    /**
     * @return distributor's infrastructure cost
     */
    public long getInfrastructureCost() {
        return infrastructureCost;
    }

    /**
     * @return distributor's production cost
     */
    public long getProductionCost() {
        return productionCost;
    }
}
