package updates;

public class UpdateFactory {
    /**
     * @param type string that defines type of update
     * @param a variable numbers of parameters for updates constructors
     * @return
     */
    public static Update createUpdate(final String type, final long...a) {
        if ("costsChanges".equals(type)) {
            return new UpdateCostsChanges(a[0], a[1], a[2]);
        }
        throw new IllegalArgumentException("The update type " + type + " is not recognized.");
    }
}
