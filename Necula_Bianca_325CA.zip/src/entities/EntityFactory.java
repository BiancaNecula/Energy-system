package entities;

public class EntityFactory {
    /**
     * @param type string that defines type of entity
     * @param a variable numbers of parameters for entities constructors
     * @return
     */
    public static Entity createEntity(final String type, final long...a) {
        switch (type) {
            case "consumer":         return new Consumer(a[0], a[1], a[2]);
            case "distributor":      return new Distributor(a[0], a[1], a[2], a[3], a[4]);
            default:
                throw new IllegalArgumentException("The entity type "
                        + type + " is not recognized.");
        }

    }
}
